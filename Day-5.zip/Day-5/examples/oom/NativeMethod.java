import java.util.concurrent.TimeUnit;

//Reason stack_trace_with_native_method
public class NativeMethod {

	public static void main(String args[]) throws Exception {

		while (true) {
			new Thread(() -> {
				try {
					TimeUnit.HOURS.sleep(1);
				} catch (InterruptedException e) {
				}
			}).start();
		}

	}

}
