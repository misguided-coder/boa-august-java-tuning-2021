public class CarExample {
	
	
	public static void main(String[] args) throws Exception {

		Car c1 = new Car(100,new String("X6"),new String("BMW"),12000.00);
		System.out.println(c1);
		Car c2 = new Car(100,new String("X2"),new String("BMWBMWBMWBMWBMWBMWBMWBMWBMWBMWBMWBMWBMWBMWBMWBMWBMWBMWBMWBMWBMWBMWBMW"),62000.00);
		System.out.println(c2);
		
		System.out.println("Enter to Exit.....");
		System.in.read();

	}

}
