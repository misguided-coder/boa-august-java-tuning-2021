import java.util.*;

public class OOMDemo3 {

	 public static void main(String args[]) {
	      int counter = 1;
	      while(true) {
	      	Employee emp = new Employee();
		emp.name = "Rohan"+counter;
		counter++;
		System.out.println(emp);
		emp = null;
		if(counter % 500 == 0) {
			System.gc();
		}
	      }
	
	}
}


class Employee {

	public String name;

	@Override
	public String toString() {
		return "Emploee [name="+this.name+"]";
	}

	@Override
	protected void finalize() {
		System.out.println(this.name + " is being gabrage collected!!!");
		/*
                try {
 		 Thread.sleep(200); //Simulating long running activity in finalize()
		}catch(Exception e){}
		*/
		this.name = null;
	}	
}
