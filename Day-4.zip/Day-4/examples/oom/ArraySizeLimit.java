import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.Date;


//-Xms512m -Xmx512m
//Requested array size exceeds VM limit
public class ArraySizeLimit {

	public static void main(String args[]) throws Exception {

		UC1();

		try {
			TimeUnit.SECONDS.sleep(4);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		UC2();

		try {
			TimeUnit.SECONDS.sleep(4);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		UC3();

		System.out.println("Done!!");
	}


	public static void UC1() throws Exception {

		for (int idx = 0; idx < 500; idx++) {
			new String("Enjoy");
			System.out.println("Generating object.....");
			try {
				TimeUnit.MILLISECONDS.sleep(10);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

	}

	public static void UC2() throws Exception {

		for (int idx = 0; idx < 100; idx++) {
			new Date();
			System.out.println("Generating date objects.....");
			try {
				TimeUnit.MILLISECONDS.sleep(10);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

	}



	public static void UC3() throws Exception {

		Integer[] array = new Integer[Integer.MAX_VALUE];
		System.out.println("Generating array.....");
		for (int idx = 0; idx < Integer.MAX_VALUE; idx++) {
			array[idx] = (new Random()).nextInt();
		}
	}

}
