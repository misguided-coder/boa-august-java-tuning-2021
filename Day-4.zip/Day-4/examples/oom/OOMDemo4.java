import java.util.*;
import java.util.concurrent.*;


public class OOMDemo4 {

    public static void main(String args[]) throws Exception {
	
	System.out.println("Enter to start....");
	System.in.read();
	//TimeUnit.MILLISECONDS.sleep(5000);	
	
	Map map = new HashMap();

	for(;true;) {
		map.put(new WonderKey("Super Key"),"Super Value"); 
	}		

    }

}


class WonderKey {
	
	public final String key;

	public WonderKey(String key) {
		this.key = key;
	}
}

