import java.util.*;

public class LeakExample3 {

    public static void main(String args[]) throws Exception {
	
	Map map = new HashMap();

	for(;true;) {
		map.put(new WonderKey("Super Key"),"Super Value"); 	 		
	}		

    }

}


class WonderKey {
	
	public final String key;

	public WonderKey(String key) {
		this.key = key;
	}

	@Override
	public boolean equals(Object other) {
		WonderKey otherObj = (WonderKey)other;	
	        return this.key.equals(otherObj.key);
        }

	@Override
	public int hashCode() {
	        return this.key.hashCode();
        }


}

